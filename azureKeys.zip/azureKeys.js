module.exports = {
	"iothub_connectionString" : 'HostName=IoTPOCGateway.azure-devices.net;SharedAccessKeyName=iothubowner;SharedAccessKey=dEwJc/FoqoNKWyziMuRwM9jpBR29ZTZg1Klxzec58mA=',
	"iothub_registryRead_key" : 'uDEQgppI4DWRIsLSJ8b18sPkxtZTA4YG90eubYVXhhQ',
	"iothub_service_key" : 'bttzFVCvcN55IwdIW+So7PVtnjGlc/c6SFQGuSz/g0Q=',
	"iothub_registryReadWrite_key" : 'nQi0F5fwmdZNu3aLRXoM4ZVYwy/tGCJwVj94VGQ92RI=',
	"iothub_iothubowner_key" : 'dEwJc/FoqoNKWyziMuRwM9jpBR29ZTZg1Klxzec58mA=',
	
	"first_device_connectionString" : 'HostName=IoTPOCGateway.azure-devices.net;DeviceId=ngscFirstNodeDevice;SharedAccessKey=PcMGegjfmDhD/YSD+NZmUXavNa4T5BnydISX8ci4rO0=',

	
    "deviceKeys" : {
        "ngscSecondDevice" : 'aKmiqhKqIOM1tvEEBNvX1MlqgGEcYeG9Gkbs6vf2FbM',
        "ngscSixthDevice" : 'unL0buq0q/aM1pgKpAXm2Dx4w7GT7ikzrJ9G4Rwkyzs='
    },
    
    
    "endpoint" : "https://itpocdocdb.documents.azure.com:443/",
    "primaryKey" : "vKRkqesPqth0wGUBPby609ljKHGNEbKiGIOKPUPIXhGd8WHKDLwrWelCAtGvj1ULqYiKe0sMDVeVPdLJEZab2A==",
    
    "database" : {
        "id": "IoTPOCSimulationTest"
    },
    
    "collection" : {
        "id": "IoTPOCSimEvents"
    }
}


